#include <iostream>
#include <bitset>
using namespace std;

typedef struct PseudoLRU treeLRU;
typedef struct Block block;

struct PseudoLRU{
	treeLRU * parent;
	bitset<1> direction;
	bitset<1> which;
	block* dataNode;
	treeLRU *left;
	treeLRU *right;
};

struct Block{
	int tag;
	//int offset;
	//int *data;
};

