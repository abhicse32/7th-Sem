#include <iostream>
#include <bitset>
#include "Logic.h"
#include <vector>
#include <iterator>
#include <boost/dynamic_bitset.hpp>
using namespace std;

int cacheLineSize=0;    
int cacheSize=0;
int associativity=0;
int nBlocks;
int nSets;

int nSetBits;      /*no of bits to be used to select a particular set*/
int nOffsetBits;   /*no of offset bits, though not relevant for the current assignment
				    but useful in to understand the flow*/
int nTagBits;      //no of tagbits 

/*
  boost library has been used to simulate real time address translation
  and further extractin address bits into setBits, offsetBits and tagBits.
  works same as std::bitset in cpp, except memory can be dynamically allocated
*/
boost::dynamic_bitset<> tagBits;
boost::dynamic_bitset<> setBits;
boost::dynamic_bitset<> offsetBits;

/*
   checks if the passed command line arguments are integers or not
*/
bool checkArg(char * str){
	int i;
	int len= strlen(str);
	for(i=0;i < len; i++){
		if(!isdigit(str[i]))
			return false;
	}
	return true;
}

/*
  Parses command-line string:
  cacheSize is followed by -(sS)
  cacheLine size is followed by -(lL)
  associativity is followed by -(aA)
*/
void parseCommand(int argc ,char * argv[]){
	int i=1;
	while(i < argc){
		switch(argv[i][1]){
			case 'l':
			case 'L':
				if(!checkArg(argv[++i])){
					cout <<"please, enter appropriate cache-Line size!!" <<endl;
					exit(1);
				}
				cacheLineSize= atoi(argv[i]);
				break;
			case 's':
			case 'S':
				if(!checkArg(argv[++i])){
					cout <<"please, enter appropriate cache size!!" <<endl;
					exit(1);
				}
				cacheSize= atoi(argv[i]);
				break;

			case 'a':
			case 'A':
				if(!checkArg(argv[++i])){
					cout <<"please, enter appropriate associativity!!" <<endl;
					exit(1);
				}
				associativity= atoi(argv[i]);
				break;
			default:
				++i;
		}
	}
}

/*
  created tree node with direction and which-bit(child-bit)
  set to 0
*/
treeLRU* createNode(){
	treeLRU* tempNode= (treeLRU*)malloc(sizeof(treeLRU));
	tempNode -> parent= NULL;
	tempNode -> left= NULL;
	tempNode -> right = NULL;
	tempNode -> dataNode= NULL;
	tempNode -> direction[0]=0;
	tempNode -> which[0] =0;
	return tempNode;
}

/*
   depending on directionBit, adds a childNode to the passedNode
*/
treeLRU* addChild(treeLRU* parentNode, bool directionBit){
	treeLRU* childNode= createNode();
	childNode -> parent = parentNode;
	childNode -> which[0] = directionBit;
	if(!directionBit)
		parentNode->left = childNode;
	else
		parentNode -> right = childNode;
	return childNode;
}

/*
  create tree for given associativity and returns 
  a vector of leafNodes of the tree.
*/
vector<treeLRU*> createTree(int  assoc, treeLRU* rootNode){
	vector<treeLRU*> nodesList;
	nodesList.push_back(rootNode);
	int listSize=nodesList.size();
	treeLRU * listFront;
	treeLRU* childNode;

	while(listSize< assoc){

		listFront= nodesList.front();
		childNode = addChild(listFront,false);
		nodesList.push_back(childNode);

		childNode= addChild(listFront, true);
		nodesList.push_back(childNode);
		
		nodesList.erase(nodesList.begin()+0);
		listSize--;
		if(!listSize)
			listSize= nodesList.size();
	}

	//cout << nodesList.size() <<endl;
	vector<treeLRU*>::iterator it= nodesList.begin();
	while(it!= nodesList.end()){
		listFront= *it;
		listFront-> dataNode= (block*)malloc(sizeof(block));
		listFront-> dataNode -> tag=0;
		it++;
	}
	return nodesList;
}

/*
  used to get the number of bits the passed argument occupies
*/
int getBits(int num){
	int counter=0;
	while(num){
		num >>= 1;
		counter++;
	}
	return counter;
}

/*
   converts hexadecimal address to binary
   and then setBit, offsetBits and TagBits are extracted from
   the resulting 32-bit address 
*/
void getBitAddress(char *address){
	boost::dynamic_bitset<> tempBits;
	boost::dynamic_bitset<> bitAddress;
	int len= strlen(address);
	unsigned long num;
	int i,j,k;
	for(i=len-1; i>= 0;i--){
		switch(address[i]){
			case '0': num=0; break;
			case '1': num=1; break;
			case '2': num=2; break;
			case '3': num=3; break;
			case '4': num=4; break;
			case '5': num=5; break;
			case '6': num=6; break;
			case '7': num=7; break;
			case '8': num=8; break;
			case '9': num=9; break;
			case 'a': case 'A': num=10; break;
			case 'b': case 'B': num=11; break;
			case 'c': case 'C': num=12; break;
			case 'd': case 'D': num=13; break;
			case 'e': case 'E': num=14; break;
			case 'f': case 'F': num=15; break;
			default:
				break;
		}
		tempBits= boost::dynamic_bitset<>(4, num);
		bitAddress.push_back(bool(tempBits[0]));
		bitAddress.push_back(bool(tempBits[1]));
		bitAddress.push_back(bool(tempBits[2]));
		bitAddress.push_back(bool(tempBits[3]));
		tempBits.clear();
	}
	for(i=8-len;i>0; i--){
		tempBits=boost::dynamic_bitset<>(4,0ul);
		bitAddress.push_back(bool(tempBits[0]));
		bitAddress.push_back(bool(tempBits[1]));
		bitAddress.push_back(bool(tempBits[2]));
		bitAddress.push_back(bool(tempBits[3]));
		tempBits.clear();
	}

	for(i=0;i< nOffsetBits; i++)
		offsetBits[i]= bitAddress[i];
	for(j=0; j< nSetBits; j++,i++)
		setBits[j]= bitAddress[i];
	for(k=0; i< 32; k++, i++)
		tagBits[k]= bitAddress[i];
	//cout << bitAddress <<endl;
	//cout << tagBits <<" "<<setBits <<" "<<offsetBits <<endl;
	bitAddress.clear(); 
}

/*
 tries to match the tag part of the address of the incoming acccess 
 with that of the tags of set-block, returns the block on success and
 NULL otherwise
*/
treeLRU* searchTag(vector<treeLRU*>blocks, int Tag){
	vector<treeLRU*>::iterator it= blocks.begin();
	treeLRU* tempNode;
	while(it != blocks.end()){
		tempNode= *it;
		if(tempNode->dataNode->tag==Tag)
			return tempNode;
		++it;
	}
	return NULL;
}

/*
  reads .out file generated by pinTool,
  uses only address of it to carry out all the operations
*/
void calculate(FILE* infile){

	vector<treeLRU*> rootList;
	vector<vector<treeLRU*> >setList;
	vector<treeLRU*> blockList;
	treeLRU* treeRoot;
	int i,j,k;
	int missCount=0;
	int conflictMissCount=0;
	int hitCount=0;

	char ip[12];
	char RW;
	char address[12];
	int setNumber, offsetNumber, tagNumber; 

	for(i=0 ; i< nSets; i++){
		treeLRU* root= createNode();
		blockList= createTree(associativity, root);
		rootList.push_back(root);
		setList.push_back(blockList);
	}

	while(fscanf(infile,"%s %c %s",ip,&RW,address)!=EOF){
		getBitAddress(address+2);
		setNumber= setBits.to_ulong();
		tagNumber= tagBits.to_ulong();

		blockList= setList[setNumber];
		treeLRU* foundBlock= searchTag(blockList, tagNumber);
		treeLRU* currNode=NULL;
		
		if(foundBlock!=NULL){
			hitCount++;
			treeLRU* parentNode=foundBlock->parent;
			currNode= foundBlock;
			while(parentNode != NULL){
				if(currNode->which[0] == parentNode->direction[0])
					parentNode->direction[0]= 1^ bool(parentNode->direction[0]);
				currNode= parentNode;
				parentNode= parentNode->parent;
			}
		}else{
			missCount++;
			treeRoot= rootList[setNumber];
			while(treeRoot!=NULL){

				if(treeRoot->left ==NULL || treeRoot->right ==NULL){
					if(treeRoot->dataNode->tag !=0)
						conflictMissCount++;
					treeRoot->dataNode->tag= tagNumber;
					treeLRU* parentNode= treeRoot->parent;
					while(parentNode!= NULL){
						parentNode->direction[0]= 1^bool(parentNode->direction[0]);
						parentNode= parentNode->parent;
					}
				}
				if(treeRoot->direction[0])
					treeRoot= treeRoot->right;
				else 
					treeRoot= treeRoot->left;
			}
		}
		//cout <<missCount <<"  " <<hitCount <<endl;
	}
	i= missCount+ hitCount;
	float missRate= (float)missCount/i;
	float hitRate = (float)hitCount/i;
	float conflictMissRate= (float)conflictMissCount/i;

	cout << "total memory accesse: "<<i <<endl;
	cout <<"total misses:" << missCount
		<<"   total conflict misses:" <<conflictMissCount <<endl;
	cout << "total missRate:" <<missRate 
		 <<"  conflict miss rate:" <<conflictMissRate <<endl;
	cout <<"\n";
	return;
}
